var i;
var n;
var soma=0;


for (i=1;i<=10;i++){
	n = parseInt(prompt("Digite o "+i+"o numero"));
	soma=soma+n;
}	
alert("a soma é "+soma);